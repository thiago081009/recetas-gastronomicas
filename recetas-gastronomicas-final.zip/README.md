# Recetas Gastronómicas

Esta página web presenta más de 10,000 recetas de España, Argentina y Francia. Cada receta incluye imágenes reales, ingredientes y videos de preparación.

## Características

- Interfaz moderna y responsive
- Galería de recetas por país
- Detalles de recetas con ingredientes y videos
- Diseño atractivo y fácil de usar
- Carga dinámica de recetas
- Videos de preparación

## Cómo usar

1. Abre la página web
2. Navega entre las secciones de España, Argentina y Francia
3. Haz clic en cualquier receta para ver sus detalles
4. Los videos de preparación se abren en YouTube

## Actualizaciones

Para cada actualización, sigue este formato para nombrar los ZIPs:

- Usa el prefijo "recetas-gastronomicas-"
- Agrega la fecha en formato YYYY-MM-DD
- Agrega una descripción breve de los cambios
- Ejemplo: "recetas-gastronomicas-2025-07-15-10000-recetas.zip"

## Créditos

Esta página fue creada por Thiago Joaquin Fernandez Marini
