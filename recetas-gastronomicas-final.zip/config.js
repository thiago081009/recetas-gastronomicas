// Configuración de API
const API_CONFIG = {
    // API key de Spoonacular
    SPOONACULAR_API_KEY: '0c8ec00b45674338acf50e156ed1ff69',
    // Configuración de la API
    API_BASE_URL: 'https://api.spoonacular.com/recipes',
    // Número máximo de recetas por petición
    RECIPES_PER_REQUEST: 100,
    // Países disponibles
    COUNTRIES: {
        'espana': 'Spanish',
        'argentina': 'Argentine',
        'francia': 'French'
    }
};

export default API_CONFIG;
