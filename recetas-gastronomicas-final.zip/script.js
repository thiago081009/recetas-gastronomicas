document.addEventListener('DOMContentLoaded', async () => {
    const modal = document.getElementById('recipe-modal');
    const closeBtn = document.querySelector('.close');
    const recipeDetails = document.getElementById('recipe-details');

    // Configuración de recetas
    const RECIPES_PER_PAGE = 10; // Número de recetas por página
    const PAGES = {
        espana: 2000, // 20,000 recetas / 10 recetas por página
        argentina: 2000,
        francia: 2000
    };

    // Función para crear una receta
    function createRecipe(id, country) {
        return {
            id: id,
            name: `${country.charAt(0).toUpperCase() + country.slice(1)} Recipe ${id}`,
            image: `https://spoonacular.com/recipeImages/${Math.floor(Math.random() * 1000000)}-312x231.jpg`,
            ingredients: [
                "Ingredient 1",
                "Ingredient 2",
                "Ingredient 3"
            ],
            video: "https://www.youtube.com/embed/1234567890",
            instructions: "Detailed instructions for this recipe"
        };
    }

    // Función para cargar recetas por país
    async function loadRecipes(country) {
        const container = document.getElementById(`${country}-recipes`);
        const loadMoreBtn = document.createElement('button');
        loadMoreBtn.textContent = 'Cargar más recetas';
        loadMoreBtn.className = 'load-more-btn';
        container.appendChild(loadMoreBtn);

        let currentPage = 1;

        // Función para cargar más recetas
        async function loadMore() {
            loadMoreBtn.disabled = true;
            loadMoreBtn.textContent = 'Cargando...';

            const start = (currentPage - 1) * RECIPES_PER_PAGE;
            const end = start + RECIPES_PER_PAGE;

            for (let i = start; i < end; i++) {
                const recipe = createRecipe(i + 1, country);
                container.insertBefore(createRecipeCard(recipe), loadMoreBtn);
            }

            currentPage++;
            
            if (currentPage > PAGES[country]) {
                loadMoreBtn.remove();
            } else {
                loadMoreBtn.disabled = false;
                loadMoreBtn.textContent = 'Cargar más recetas';
            }
        }

        // Cargar las primeras recetas
        await loadMore();

        // Agregar evento al botón
        loadMoreBtn.addEventListener('click', loadMore);
    }

    // Función para obtener video de YouTube
    function getRecipeVideo(recipeName) {
        const searchQuery = encodeURIComponent(`${recipeName} recipe`);
        return `https://www.youtube.com/embed/${searchQuery}`;
    }

    // Función para crear tarjetas de recetas
    function createRecipeCard(recipe) {
        const card = document.createElement('div');
        card.className = 'recipe-card';
        card.innerHTML = `
            <img src="${recipe.image}" alt="${recipe.name}">
            <h3>${recipe.name}</h3>
        `;
        card.addEventListener('click', () => showRecipeDetails(recipe));
        return card;
    }

    // Función para mostrar detalles de la receta
    function showRecipeDetails(recipe) {
        recipeDetails.innerHTML = `
            <h2>${recipe.name}</h2>
            <div class="ingredients">
                <h3>Ingredientes:</h3>
                <ul>
                    ${recipe.ingredients.map(ing => `<li>${ing}</li>`).join('')}
                </ul>
            </div>
            <div class="video-container">
                <h3>Video de preparación:</h3>
                <iframe width="560" height="315" src="${recipe.video}" frameborder="0" allowfullscreen></iframe>
            </div>
        `;
        modal.style.display = 'block';
    }

    // Cerrar modal
    closeBtn.onclick = () => modal.style.display = 'none';
    window.onclick = (event) => {
        if (event.target === modal) {
            modal.style.display = 'none';
        }
    };

    // Cargar recetas
    function loadRecipes() {
        Object.entries(recipes).forEach(([country, recipes]) => {
            const container = document.getElementById(`${country}-recipes`);
            recipes.forEach(recipe => {
                container.appendChild(createRecipeCard(recipe));
            });
        });
    }

    loadRecipes();
});
